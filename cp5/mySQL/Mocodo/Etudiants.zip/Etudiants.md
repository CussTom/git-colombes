**etudie** (<ins>#code_e</ins>, <ins>#code_m</ins>, note)  
**etudiants** (<ins>code_e</ins>, nom-e, ddn, sexe)  
**matieres** (<ins>code_m</ins>, nom_m, coeff, #code_p)  
**enseignants** (<ins>code_p</ins>, nom_p, grade, embauche)